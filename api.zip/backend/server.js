const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();

// Enable CORS for all routes
app.use(cors());

app.get('/api/stock-positions', async (req, res) => {
    try {
        const url = 'https://api.dhan.co/v2/holdings'; // API endpoint
        const headers = {
            'access-token': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJkaGFuIiwicGFydG5lcklkIjoiIiwiZXhwIjoxNzMzNTY5OTM0LCJ0b2tlbkNvbnN1bWVyVHlwZSI6IlNFTEYiLCJ3ZWJob29rVXJsIjoiIiwiZGhhbkNsaWVudElkIjoiMTEwMTg0MzY4MCJ9.4r8-SQI8qNqaSqRltDFlQRdMozmQqqrOjFJ7VLb3S8vVET7Ubmhwmbh1FcmXURNLsYEHp9ZyAL5r0PaKmV0DyQ',
            'Accept': 'application/json',
        };

        // Fetch data from the external API
        const response = await axios.get(url, { headers });

        // Send the response data to the client
        res.status(200).json(response.data);
    } catch (error) {
        console.error(`Error fetching stock positions: ${error.message}`);
        res.status(500).json({
            error: 'Failed to fetch stock positions',
            details: error.message,
        });
    }
});

// Start the server
const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
