from flask import Flask, jsonify
from flask_cors import CORS  # To handle CORS issues
import requests

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

@app.route('/api/stock-positions', methods=['GET'])
def get_stock_positions():
    try:
        # Define the API endpoint and headers
        url = 'https://api.dhan.co/v2/holdings'
        # url = 'https://api.dhan.co/v2/positions'
        headers = {
            'access-token': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJkaGFuIiwicGFydG5lcklkIjoiIiwiZXhwIjoxNzMzNTY5OTM0LCJ0b2tlbkNvbnN1bWVyVHlwZSI6IlNFTEYiLCJ3ZWJob29rVXJsIjoiIiwiZGhhbkNsaWVudElkIjoiMTEwMTg0MzY4MCJ9.4r8-SQI8qNqaSqRltDFlQRdMozmQqqrOjFJ7VLb3S8vVET7Ubmhwmbh1FcmXURNLsYEHp9ZyAL5r0PaKmV0DyQ',
            'Accept': 'application/json',
        }
        # Send GET request to the API
        response = requests.get(url, headers=headers)
    
        # Check for successful response
        response.raise_for_status()  # Raise an error for bad status codes

        # Return the parsed JSON response
        return jsonify(response.json()), 200

    except requests.exceptions.RequestException as e:
        # Log error and return response
        print(f"Error fetching stock positions: {e}")
        return jsonify({
            'error': 'Failed to fetch stock positions',
            'details': str(e)
        }), 500

if __name__ == '__main__':
    app.run(debug=True)
