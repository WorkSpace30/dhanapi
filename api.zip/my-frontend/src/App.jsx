import React from "react";
import StockPositions from "./components/StockPositions";

const App = () => {
  return (
    <div>
      <StockPositions />
    </div>
  );
};

export default App;
// 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJkaGFuIiwicGFydG5lcklkIjoiIiwiZXhwIjoxNzMzNTY5OTM0LCJ0b2tlbkNvbnN1bWVyVHlwZSI6IlNFTEYiLCJ3ZWJob29rVXJsIjoiIiwiZGhhbkNsaWVudElkIjoiMTEwMTg0MzY4MCJ9.4r8-SQI8qNqaSqRltDFlQRdMozmQqqrOjFJ7VLb3S8vVET7Ubmhwmbh1FcmXURNLsYEHp9ZyAL5r0PaKmV0DyQ'