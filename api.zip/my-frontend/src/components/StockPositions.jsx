import React, { useEffect, useState } from "react";
import axios from 'axios';

const StockPositions = () => {
    const [stockPositions, setStockPositions] = useState(null);
    const [error, setError] = useState(null);

    useEffect(() => {
        // Fetch data from Node.js API using axios
        axios
            .get('http://127.0.0.1:5000/api/stock-positions')
            .then((response) => setStockPositions(response.data))
            .catch((err) => setError(err));
    }, []);

    return (
        <div>
            <h1>Stock Positions</h1>
            {error && <p>Error fetching data: {error.message}</p>}
            {stockPositions ? (
                <pre>{JSON.stringify(stockPositions, null, 2)}</pre>
            ) : (
                <p>Loading...</p>
            )}
        </div>
    );
};

export default StockPositions;